/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PASPORT;

import com.oreilly.servlet.MultipartRequest;
import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;
import DBconnection.SQLconnection;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author java3
 */
public class Location_encryption extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {

            String loc = request.getParameter("location");

            Connection con = SQLconnection.getconnection();

            KeyGenerator Attrib_key = KeyGenerator.getInstance("AES");
            Attrib_key.init(128);
            SecretKey secretKey = Attrib_key.generateKey();
            System.out.println("++++++++ key:" + secretKey);

            Encryption e = new Encryption();
            String en_location = e.encrypt(loc, secretKey);
            //storing encrypted file

            byte[] b = secretKey.getEncoded();
            String Dkey = Base64.encode(b);
            System.out.println("converted secretkey to string:" + Dkey);

            HttpSession session = request.getSession();

            HttpSession user = request.getSession(true);
            String pmail = user.getAttribute("umail").toString();
            String pname = user.getAttribute("uname").toString();
            String pid = user.getAttribute("uid").toString();

            DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
            Date date = new Date();
            String time = dateFormat.format(date);
            System.out.println("current Date " + time);

            Statement st = con.createStatement();
            Statement st1 = con.createStatement();

            System.out.println("Check------------------------------------------------------------------>>>>>");

            ResultSet rs = st.executeQuery(" Select * from location where pid ='" + pid + "' AND pname = '" + pname + "'");

            if (rs.next()) {

                response.sendRedirect("location_request1.jsp?location_encrypted");

            } else {
                ResultSet rs1 = st1.executeQuery(" Select * from user_reg where id ='" + pid + "' AND name = '" + pname + "'");
                if (rs1.next()) {
                    String org_location = rs1.getString("address");

                    int i = st.executeUpdate("insert into location(pname, pmail, pid, location, time, dkey, en_location, org_location)values('" + pname + "','" + pmail + "','" + pid + "','" + loc + "','" + time + "','" + Dkey + "','" + en_location + "','" + org_location + "')");
                    if (i != 0) {
                        response.sendRedirect("location_request1.jsp?location_encrypted");
                    } else {
                        System.out.println("Error in SQL Syntex");
                    }
                } else {
                    System.out.println("Error in SQL Syntex");
                }
            }

        } catch (Exception e) {
            out.println(e);
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
